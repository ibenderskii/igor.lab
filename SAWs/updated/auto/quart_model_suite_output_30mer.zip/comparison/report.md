# Model suite report

Generated: 2026-07-31T02:12:27.822729+00:00

## Configuration

- Target REMD: `/scratch/midway2/ibenderskii/auto/remd_distributions_30mer.npz`
- Models: hs, hs_m2_const, hs_m2_hs, saturating_cooperative_contact
- Baselines: final_joint_baseline_30mer
- Output root: `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_30mer`

## Jobs

- Fits succeeded: 4; fits failed/incomplete: 0
- REMD seeds succeeded: 40; failed: 0

## Baseline: final_joint_baseline_30mer

- **Simulation winner:** saturating_cooperative_contact (all-temperature combined JS 0.09256)
- **Analytic-fit winner:** saturating_cooperative_contact (all-temperature contact loss 1.374)

### Analytic fit ranking

| rank | model | val contact loss | all contact loss |
|---|---|---|---|
| 1 | saturating_cooperative_contact | n/a | 1.374 |
| 2 | hs_m2_hs | n/a | 1.622 |
| 3 | hs_m2_const | n/a | 1.687 |
| 4 | hs | n/a | 3.178 |

### REMD simulation ranking

| rank | model | combined JS (mean±std) | contact JS | Rg JS | note |
|---|---|---|---|---|---|
| 1 | saturating_cooperative_contact | 0.09256±0.0003895 | 0.03399 | 0.08367 |  |
| 2 | hs_m2_hs | 0.09679±0.0005271 | 0.03942 | 0.08196 |  |
| 3 | hs_m2_const | 0.09871±0.0003115 | 0.04111 | 0.08228 |  |
| 4 | hs | 0.1276±0.0004876 | 0.07451 | 0.07583 |  |

### Diagnostics

- Possible overfitting (val ≫ train fit loss): none
- REMD does not reproduce analytic prediction (REMD↔fit contact JS > 0.05): none
- Convergence warnings (min swap rate < 0.05): none

## Fit robustness and parameter identifiability

_Fitter-side diagnostics. These qualify but never replace the REMD simulation ranking. Bootstrap intervals are empirical temperature-resampling ranges, not likelihood standard errors._

### Baseline: final_joint_baseline_30mer

| model | bootstrap success | widest rel CI | max |corr| | split stability | Rg-weight | optimizer/identifiability |
|---|---|---|---|---|---|---|
| hs | 200/200 | 0.047 | 0.9986 | off | off | off |
| hs_m2_const | 200/200 | 0.14 | 0.9638 | off | off | off |
| hs_m2_hs | 200/200 | 0.41 | 0.9999 | off | off | off |
| saturating_cooperative_contact | 200/200 | 0.15 | 0.9064 | off | off | off |

#### Bootstrap uncertainty

- **hs**: strong parameter correlation(s): h~s=0.9986 (possible non-identifiability).
- **hs_m2_const**: strong parameter correlation(s): h1~s1=0.9638 (possible non-identifiability).
- **hs_m2_hs**: strong parameter correlation(s): h1~s1=0.9998, h1~h2=-0.9942, h1~s2=-0.995, s1~h2=-0.9932, s1~s2=-0.9942, h2~s2=0.9999 (possible non-identifiability).
- **saturating_cooperative_contact**: strong parameter correlation(s): h_b~s_b=0.9064 (possible non-identifiability).

### Recommendation qualified by robustness

- **final_joint_baseline_30mer:** primary REMD pick is **saturating_cooperative_contact** (combined JS 0.09256); robustness-qualified recommendation: **saturating_cooperative_contact**.

## Global cross-baseline ranking

_Not produced: baselines differ in offset/Rg-units/metric config, or only one baseline. Per-baseline rankings above apply._

## Outputs

- `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_30mer/comparison/model_comparison.csv`
- `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_30mer/comparison/per_temperature_metrics.csv`
- `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_30mer/comparison/plots`
- `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_30mer/manifest.json`
- `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_30mer/comparison/fit_robustness_summary.json`
- `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_30mer/comparison/fit_robustness.csv`
