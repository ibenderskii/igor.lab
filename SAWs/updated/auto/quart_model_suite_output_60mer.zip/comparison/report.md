# Model suite report

Generated: 2026-07-30T23:31:27.568068+00:00

## Configuration

- Target REMD: `/scratch/midway2/ibenderskii/auto/remd_distributions_60mer.npz`
- Models: hs, hs_m2_const, hs_m2_hs, saturating_cooperative_contact
- Baselines: final_joint_baseline_60mer
- Output root: `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_60mer`

## Jobs

- Fits succeeded: 4; fits failed/incomplete: 0
- REMD seeds succeeded: 40; failed: 0

## Baseline: final_joint_baseline_60mer

- **Simulation winner:** saturating_cooperative_contact (all-temperature combined JS 0.0642)
- **Analytic-fit winner:** saturating_cooperative_contact (all-temperature contact loss 1.946)

### Analytic fit ranking

| rank | model | val contact loss | all contact loss |
|---|---|---|---|
| 1 | saturating_cooperative_contact | n/a | 1.946 |
| 2 | hs_m2_hs | n/a | 2.759 |
| 3 | hs_m2_const | n/a | 2.982 |
| 4 | hs | n/a | 5.94 |

### REMD simulation ranking

| rank | model | combined JS (mean±std) | contact JS | Rg JS | note |
|---|---|---|---|---|---|
| 1 | saturating_cooperative_contact | 0.0642±0.0003668 | 0.0446 | 0.03921 |  |
| 2 | hs_m2_hs | 0.07137±0.0009177 | 0.04672 | 0.0493 |  |
| 3 | hs_m2_const | 0.07392±0.0003836 | 0.04526 | 0.05734 |  |
| 4 | hs | 0.1555±0.001029 | 0.1389 | 0.03333 |  |

### Diagnostics

- Possible overfitting (val ≫ train fit loss): none
- REMD does not reproduce analytic prediction (REMD↔fit contact JS > 0.05): none
- Convergence warnings (min swap rate < 0.05): none

## Fit robustness and parameter identifiability

_Fitter-side diagnostics. These qualify but never replace the REMD simulation ranking. Bootstrap intervals are empirical temperature-resampling ranges, not likelihood standard errors._

### Baseline: final_joint_baseline_60mer

| model | bootstrap success | widest rel CI | max |corr| | split stability | Rg-weight | optimizer/identifiability |
|---|---|---|---|---|---|---|
| hs | 200/200 | 0.14 | 0.9982 | off | off | off |
| hs_m2_const | 200/200 | 0.14 | 0.9066 | off | off | off |
| hs_m2_hs | 200/200 | 0.15 | 0.9986 | off | off | off |
| saturating_cooperative_contact | 200/200 | 0.27 | 0.9911 | off | off | off |

#### Bootstrap uncertainty

- **hs**: strong parameter correlation(s): h~s=0.9982 (possible non-identifiability).
- **hs_m2_const**: strong parameter correlation(s): h1~s1=0.9066 (possible non-identifiability).
- **hs_m2_hs**: strong parameter correlation(s): h1~s1=0.9985, h1~h2=-0.9933, h1~s2=-0.9905, s1~h2=-0.9932, s1~s2=-0.9933, h2~s2=0.9986 (possible non-identifiability).
- **saturating_cooperative_contact**: strong parameter correlation(s): h_b~s_b=0.9911, h_b~A0=-0.9391, h_b~q_sat=-0.946, s_b~A0=-0.9763, s_b~q_sat=-0.9775, A0~q_sat=0.9875 (possible non-identifiability).

### Recommendation qualified by robustness

- **final_joint_baseline_60mer:** primary REMD pick is **saturating_cooperative_contact** (combined JS 0.0642); robustness-qualified recommendation: **saturating_cooperative_contact**.

## Global cross-baseline ranking

_Not produced: baselines differ in offset/Rg-units/metric config, or only one baseline. Per-baseline rankings above apply._

## Outputs

- `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_60mer/comparison/model_comparison.csv`
- `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_60mer/comparison/per_temperature_metrics.csv`
- `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_60mer/comparison/plots`
- `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_60mer/manifest.json`
- `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_60mer/comparison/fit_robustness_summary.json`
- `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_60mer/comparison/fit_robustness.csv`
