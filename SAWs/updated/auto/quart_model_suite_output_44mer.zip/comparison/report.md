# Model suite report

Generated: 2026-07-30T11:24:26.803606+00:00

## Configuration

- Target REMD: `/scratch/midway2/ibenderskii/auto/remd_distributions_44mer.npz`
- Models: hs, hs_m2_const, hs_m2_hs, saturating_cooperative_contact
- Baselines: final_joint_baseline_44mer
- Output root: `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_44mer`

## Jobs

- Fits succeeded: 4; fits failed/incomplete: 0
- REMD seeds succeeded: 40; failed: 0

## Baseline: final_joint_baseline_44mer

- **Simulation winner:** saturating_cooperative_contact (all-temperature combined JS 0.03019)
- **Analytic-fit winner:** saturating_cooperative_contact (all-temperature contact loss 0.6311)

### Analytic fit ranking

| rank | model | val contact loss | all contact loss |
|---|---|---|---|
| 1 | saturating_cooperative_contact | n/a | 0.6311 |
| 2 | hs_m2_hs | n/a | 0.9158 |
| 3 | hs_m2_const | n/a | 0.9968 |
| 4 | hs | n/a | 3.246 |

### REMD simulation ranking

| rank | model | combined JS (mean±std) | contact JS | Rg JS | note |
|---|---|---|---|---|---|
| 1 | saturating_cooperative_contact | 0.03019±0.0002662 | 0.01433 | 0.03173 |  |
| 2 | hs_m2_hs | 0.04123±0.0005128 | 0.01898 | 0.04451 |  |
| 3 | hs_m2_const | 0.04462±0.0005144 | 0.02041 | 0.04843 |  |
| 4 | hs | 0.08817±0.0005291 | 0.07689 | 0.02256 |  |

### Diagnostics

- Possible overfitting (val ≫ train fit loss): none
- REMD does not reproduce analytic prediction (REMD↔fit contact JS > 0.05): none
- Convergence warnings (min swap rate < 0.05): none

## Fit robustness and parameter identifiability

_Fitter-side diagnostics. These qualify but never replace the REMD simulation ranking. Bootstrap intervals are empirical temperature-resampling ranges, not likelihood standard errors._

### Baseline: final_joint_baseline_44mer

| model | bootstrap success | widest rel CI | max |corr| | split stability | Rg-weight | optimizer/identifiability |
|---|---|---|---|---|---|---|
| hs | 200/200 | 0.13 | 0.9982 | off | off | off |
| hs_m2_const | 200/200 | 0.086 | 0.8997 | off | off | off |
| hs_m2_hs | 200/200 | 0.19 | 0.9975 | off | off | off |
| saturating_cooperative_contact | 200/200 | 0.15 | 0.9983 | off | off | off |

#### Bootstrap uncertainty

- **hs**: strong parameter correlation(s): h~s=0.9982 (possible non-identifiability).
- **hs_m2_const**: parameters appear well constrained; no intervals bracket zero and no strong correlations flagged.
- **hs_m2_hs**: strong parameter correlation(s): h1~s1=0.9975, h1~h2=-0.9277, h1~s2=-0.9456, s1~h2=-0.9112, s1~s2=-0.9339, h2~s2=0.9971 (possible non-identifiability).
- **saturating_cooperative_contact**: strong parameter correlation(s): h_b~s_b=0.9983, h_b~A0=-0.9927, h_b~q_sat=-0.9893, s_b~A0=-0.998, s_b~q_sat=-0.9951, A0~q_sat=0.996 (possible non-identifiability).

### Recommendation qualified by robustness

- **final_joint_baseline_44mer:** primary REMD pick is **saturating_cooperative_contact** (combined JS 0.03019); robustness-qualified recommendation: **saturating_cooperative_contact**.

## Global cross-baseline ranking

_Not produced: baselines differ in offset/Rg-units/metric config, or only one baseline. Per-baseline rankings above apply._

## Outputs

- `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_44mer/comparison/model_comparison.csv`
- `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_44mer/comparison/per_temperature_metrics.csv`
- `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_44mer/comparison/plots`
- `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_44mer/manifest.json`
- `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_44mer/comparison/fit_robustness_summary.json`
- `/scratch/midway2/ibenderskii/auto/quart_model_suite_output_44mer/comparison/fit_robustness.csv`
